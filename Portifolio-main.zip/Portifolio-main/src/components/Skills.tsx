
import React from "react";
import SkillCard from "./SkillCard";
import { Code, Database, Globe, Shield, Server } from "lucide-react";

const Skills = () => {
  const programmingSkills = [
    { name: "C#", level: 85, icon: <Code /> },
    { name: "Java", level: 80, icon: <Code /> },
    { name: "Python", level: 75, icon: <Code /> },
  ];

  const webSkills = [
    { name: "HTML & CSS", level: 90, icon: <Globe /> },
    { name: "JavaScript", level: 85, icon: <Code /> },
    { name: "React", level: 80, icon: <Code /> },
    { name: "ASP.NET Web API", level: 75, icon: <Server /> },
  ];

  const databaseSkills = [
    { name: "SQL", level: 85, icon: <Database /> },
    { name: "SQL Server", level: 80, icon: <Database /> },
  ];

  const securitySkills = [
    { name: "Network Security", level: 70, icon: <Shield /> },
    { name: "Web Security", level: 75, icon: <Shield /> },
    { name: "Secure Coding", level: 80, icon: <Shield /> },
  ];

  return (
    <section id="skills" className="section bg-tech-darker">
      <div className="container mx-auto px-4">
        <h2 className="section-title text-tech-light">Skills</h2>

        <div className="space-y-10">
          <div>
            <h3 className="text-xl font-semibold mb-4 text-tech-light">Programming Languages</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {programmingSkills.map((skill) => (
                <SkillCard 
                  key={skill.name} 
                  name={skill.name} 
                  icon={skill.icon} 
                  level={skill.level}
                />
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-4 text-tech-light">Web Development</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {webSkills.map((skill) => (
                <SkillCard 
                  key={skill.name} 
                  name={skill.name} 
                  icon={skill.icon} 
                  level={skill.level}
                />
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-xl font-semibold mb-4 text-tech-light">Database</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {databaseSkills.map((skill) => (
                <SkillCard 
                  key={skill.name} 
                  name={skill.name} 
                  icon={skill.icon} 
                  level={skill.level}
                />
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4 text-tech-light">Security</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {securitySkills.map((skill) => (
                <SkillCard 
                  key={skill.name} 
                  name={skill.name} 
                  icon={skill.icon} 
                  level={skill.level}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
