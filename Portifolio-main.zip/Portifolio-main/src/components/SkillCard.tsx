
import React from 'react';

interface SkillCardProps {
  name: string;
  icon: React.ReactNode;
  level?: number;
}

const SkillCard: React.FC<SkillCardProps> = ({ name, icon, level = 0 }) => {
  return (
    <div className="skill-item group transition-all duration-300 hover:transform hover:-translate-y-1">
      <div className="text-3xl mb-2 text-tech-neon group-hover:text-tech-cyan transition-colors">{icon}</div>
      <h3 className="font-medium text-tech-light">{name}</h3>
      {level > 0 && (
        <div className="w-full bg-tech-dark rounded-full h-1.5 mt-2">
          <div 
            className="bg-tech-neon h-1.5 rounded-full shadow-[0_0_5px_rgba(80,250,123,0.5)]" 
            style={{ width: `${level}%` }}
          ></div>
        </div>
      )}
    </div>
  );
};

export default SkillCard;
