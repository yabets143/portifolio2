
import React from "react";
import { Briefcase, Calendar } from "lucide-react";

const Experience = () => {
  return (
    <section id="experience" className="section bg-tech-dark">
      <div className="container mx-auto px-4">
        <h2 className="section-title text-tech-light">Experience</h2>

        <div className="max-w-3xl mx-auto">
          <div className="relative border-l-2 border-tech-cyan pl-8 pb-6">
            {/* Timeline dot */}
            <div className="absolute -left-[9px] top-0 h-4 w-4 rounded-full bg-tech-cyan border-4 border-tech-dark"></div>
            
            <div className="card bg-tech-darker border-tech-neon/20">
              <div className="flex justify-between items-start mb-3">
                <h3 className="font-bold text-xl text-tech-light">Software Development Intern</h3>
                <span className="bg-tech-neon/20 text-tech-neon text-xs px-2 py-1 rounded-full">
                  Internship
                </span>
              </div>
              
              <div className="mb-4">
                <div className="flex items-center text-tech-cyan mb-1">
                  <Briefcase className="h-4 w-4 mr-2" />
                  <span>CyberSoft-intl</span>
                </div>
                <div className="flex items-center text-tech-cyan">
                  <Calendar className="h-4 w-4 mr-2" />
                  <span>June 2023 - August 2023</span>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold mb-2 text-tech-light">Responsibilities & Achievements:</h4>
                <ul className="list-disc list-inside space-y-2 text-tech-light/80">
                  <li>Developed a secure user authentication module using ASP.NET Identity framework</li>
                  <li>Implemented input validation and sanitization to prevent SQL injection and XSS attacks</li>
                  <li>Assisted in security auditing and vulnerability assessment of existing applications</li>
                  <li>Created documentation for secure coding practices for the development team</li>
                  <li>Collaborated with senior developers on the implementation of secure API endpoints</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;
